package com.capg.paymentwallet.dao;

import java.math.BigInteger;

import com.capg.paymentwallet.bean.Account;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;

public interface IDaoInterface {

	
	
	public boolean createAccount(Account accountBean) throws Exception;
	public Account findAccount(int accId) throws Exception;

	public boolean updateAccount(Account accountBean) throws Exception;

}
