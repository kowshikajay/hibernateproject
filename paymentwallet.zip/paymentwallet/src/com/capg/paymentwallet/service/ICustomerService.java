package com.capg.paymentwallet.service;

import java.math.BigInteger;

import com.capg.paymentwallet.bean.Account;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;

public interface ICustomerService {

//	public boolean fundTransfer(long accNum);

	
	

	

	public boolean createAccount(Account accountBean) throws Exception;

	public Account findAccount(int accId) throws Exception;


	public boolean deposit(Account accountBean, double depositAmt) throws Exception;



	public boolean withdraw(Account accountBean, double withdrawAmt) throws Exception;



	public boolean fundTransfer(Account transferingAccountBean, Account beneficiaryAccountBean,
			double transferAmount) throws Exception;

	//public boolean createvalidate(CustomerBean customer) throws CustomerException;


	
}
