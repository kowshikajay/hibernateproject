package com.capg.paymentwallet.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.capg.paymentwallet.bean.Account;

import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.Transfer;

import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.CustomerServiceImp;
import com.capg.paymentwallet.service.ICustomerService;

public class Client {

	public static void main(String[] args) throws Exception {
		Account accountBean = new Account();
		Transfer transfer = new Transfer();
		CustomerBean customer = new CustomerBean();
		ICustomerService service = new CustomerServiceImp();
		while (true) {
			System.out
					.println("----------welcome to wallet application------------");
			System.out.println("1.create account");
			System.out.println("2.show balance");
			System.out.println("3.deposit");
			System.out.println("4.withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.print transactions");
			System.out.println("7.exit");
			Scanner sc = new Scanner(System.in);

			int choice = sc.nextInt();
			switch (choice) {

			case 1:
				System.out.println("enter your first name");
				String fname = sc.next();
				customer.setFirstName(fname);
				System.out.println("enter your last name");
				String lname = sc.next();
				customer.setLastName(lname);
				System.out.println("enter your age");
				int age = sc.nextInt();
				customer.setAge(age);
				System.out.println("enter your mobile number:");
				String phno = sc.next();
				customer.setPhoneNo(phno);
				System.out.println("enter your mail-id");
				String mail = sc.next();
				customer.setEmailId(mail);
				System.out.println("Enter your PAN number");
				String panNum = sc.next();
				customer.setPanNum(panNum);
				System.out.println("Enter your address");
				String add = sc.next();
				customer.setAddress(add);

				customer.setAddress(add);
				customer.setEmailId(mail);
				customer.setPanNum(panNum);
				customer.setPhoneNo(phno);
				customer.setFirstName(fname);
				customer.setLastName(lname);
				System.out.println("Enter  Account ID");
				int accId = sc.nextInt();

				System.out.println("Enter Date of Opening (DD/MM/YYYY)");
				String accDateInput = sc.next();

				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				Date dateOfOpeining = sdf.parse(accDateInput);

				System.out.println("Enter balance to create account");
				double balance = sc.nextDouble();

				accountBean.setAccountId(accId);
				accountBean.setBalance(balance);
				accountBean.setInitialDeposit(balance);
				accountBean.setCustomerBean(customer);

				boolean result = service.createAccount(accountBean);
				

					if (result == true) {
						System.out
								.println("\n \n Account successfully created");
					} else {
						System.out.println("sorry account not created");
					}
				
		
				break;
			case 2:
				System.out.println("Enter your Account number");
				int accId1 = sc.nextInt();
				Account account = service.findAccount(accId1);

				if (account == null) {
					System.out.println("Account Does not exist");
					return;
				}

				double balance1 = accountBean.getBalance();

				System.out.println("Your balance is: " + balance1);

				break;
			case 3:
				System.out.println("Enter Account ID");
				int accId2 = sc.nextInt();

				Account accountBean2 = service.findAccount(accId2);

				System.out.println("Enter amount that you want to deposit");
				double depositAmt = sc.nextDouble();

				Transfer wt = new Transfer();
				wt.setTransactionType(1);
				wt.setTransactionDate(new Date());
				wt.setTransactionAmt(depositAmt);
				wt.setBeneficiaryAccountBean(null);

				accountBean.addTransation(wt);

				if (accountBean == null) {
					System.out.println("Account Does not exist");
					return;
				}

				boolean result1 = service.deposit(accountBean, depositAmt);

				if (result1) {
					System.out.println("Deposited Money into Account ");
				} else {
					System.out.println("NOT Deposited Money into Account ");
				}
				break;
			case 4:
				System.out.println("Enter Account ID");
				int accId3 = sc.nextInt();

				Account accountBean3 = service.findAccount(accId3);

				System.out.println("Enter amount that you want to withdraw");
				double withdrawAmt = sc.nextDouble();

				Transfer wt1 = new Transfer();
				wt1.setTransactionType(2);
				wt1.setTransactionDate(new Date());
				wt1.setTransactionAmt(withdrawAmt);
				wt1.setBeneficiaryAccountBean(null);

				accountBean.addTransation(wt1);

				if (accountBean == null) {
					System.out.println("Account Does not exist");
					return;
				}

				boolean isValid = service.withdraw(accountBean, withdrawAmt);
				if (isValid) {
					System.out.println("Withdaw Money from Account done");
				} else {
					System.out.println("Withdaw Money from Account -Failed ");
				}
				break;
			case 5:
				System.out.println("Enter Account ID to Transfer Money From");
				int srcAccId = sc.nextInt();

				Account accountBean1 = service.findAccount(srcAccId);

				System.out.println("Enter Account ID to Transfer Money to");
				int targetAccId = sc.nextInt();

				Account accountBean4 = service.findAccount(targetAccId);

				System.out.println("Enter amount that you want to transfer");
				double transferAmt = sc.nextDouble();

				Transfer wt4 = new Transfer();
				wt4.setTransactionType(3);
				wt4.setTransactionDate(new Date());
				wt4.setTransactionAmt(transferAmt);
				wt4.setBeneficiaryAccountBean(accountBean4);

				accountBean1.addTransation(wt4);

				boolean result4 = service.fundTransfer(accountBean1,
						accountBean4, transferAmt);

				if (result4) {
					System.out.println("Transfering Money from Account done");
				} else {
					System.out
							.println("Transfering Money from Account Failed ");
				}
				break;
			case 6:
				System.out
						.println("Enter Account ID (for printing Transaction Details");
				int accId6 = sc.nextInt();

				Account accountBean6 = service.findAccount(accId6);

				List<Transfer> transactions = accountBean.getAllTransactions();

				System.out.println(accountBean);
				System.out.println(accountBean.getCustomerBean());

				System.out
						.println("------------------------------------------------------------------");

				for (Transfer wt6 : transactions) {

					String str = "";
					if (wt6.getTransactionType() == 1) {
						str = str + "DEPOSIT";
					}
					if (wt6.getTransactionType() == 2) {
						str = str + "WITHDRAW";
					}
					if (wt6.getTransactionType() == 3) {
						str = str + "FUND TRANSFER";
					}

					str = str + "\t\t" + wt6.getTransactionDate();

					str = str + "\t\t" + wt6.getTransactionAmt();
					System.out.println(str);
				}

				System.out
						.println("------------------------------------------------------------------");

			case 7:
				System.exit(0);

				break;
			default:
				System.err.println("Invalid choice");
			}

		}
	}
}